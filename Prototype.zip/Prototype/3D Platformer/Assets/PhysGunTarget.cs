﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysGunTarget : MonoBehaviour {

    [SerializeField] public bool transformX = true;
    [SerializeField] public bool transformY = true;
    [SerializeField] public bool transformZ = true;

    private Vector3 previousPosition = Vector3.zero;
    private Vector3 transformVelocity = Vector3.zero;

    [SerializeField] private bool manualConstraints = false;
    private bool finishFixedUpdate = false;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnStart()
    {
        finishFixedUpdate = false;
        if (manualConstraints) return;
        GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionY;
        //previousPosition = transform.position;
    }

    public void OnFinish()
    {        
        finishFixedUpdate = true;        

        if (manualConstraints) return;
        GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
    }

    public void Control(Transform seeker, GameObject beam, int controlType)
    {        
        switch (controlType)
        {
            case 0:

                Vector3 newPosition = new Vector3(transform.position.x, transform.position.y, transform.position.z);
                if (transformX)
                    newPosition.x = seeker.position.x;
                if (transformY)
                    newPosition.y = seeker.position.y;
                if (transformZ)
                    newPosition.z = seeker.position.z;

                transform.position = newPosition;

                break;

            case 1:

                Vector3 mousePosition = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Input.mousePosition.z - Camera.main.transform.position.z));
                Vector3 relativePosition = new Vector3(mousePosition.x, mousePosition.y, beam.transform.position.z);

                relativePosition.x = (transformX) ? relativePosition.x : transform.position.x;
                relativePosition.y = (transformY) ? relativePosition.y : transform.position.y;
                relativePosition.z = (transformZ) ? relativePosition.z : transform.position.z;

                Vector3 targetedPosition = Vector3.Lerp(seeker.transform.position, relativePosition, Time.deltaTime * 3.5f / GetComponent<Rigidbody>().mass);
                transform.position = Vector3.MoveTowards(targetedPosition, relativePosition, Time.deltaTime);
                Debug.Log(transform.position + " -- " + GetComponent<Rigidbody>().position);
                seeker.transform.position = transform.position;

                break;
        }
    }

    private void FixedUpdate()
    {
        CalculateTransformVelocity();

        if(finishFixedUpdate)
        {
            GetComponent<Rigidbody>().velocity = Vector3.zero;
            GetComponent<Rigidbody>().AddForce(transformVelocity, ForceMode.VelocityChange);
            finishFixedUpdate = false;
        }
    }

    private void CalculateTransformVelocity()
    {
        transformVelocity = (transform.position - previousPosition) / Time.deltaTime;
        Debug.Log("Velocity " + transformVelocity);

        previousPosition = transform.position;
    }
}
